from langchain_community.document_loaders.base_o365 import (
    O365BaseLoader,
)

__all__ = [
    "O365BaseLoader",
]
