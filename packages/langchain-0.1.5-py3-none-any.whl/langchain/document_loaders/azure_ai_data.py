from langchain_community.document_loaders.azure_ai_data import AzureAIDataLoader

__all__ = ["AzureAIDataLoader"]
