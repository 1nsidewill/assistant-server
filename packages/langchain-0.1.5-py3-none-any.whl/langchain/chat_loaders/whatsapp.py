from langchain_community.chat_loaders.whatsapp import WhatsAppChatLoader

__all__ = ["WhatsAppChatLoader"]
