"""Callback Handler that prints to std out."""
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, TypeVar, Union, Iterable, Tuple
from uuid import UUID

from tenacity import RetryCallState

from langchain_core.agents import AgentAction, AgentFinish
from langchain_core.documents import Document
from langchain_core.messages import BaseMessage
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.outputs import ChatGenerationChunk, GenerationChunk, LLMResult

try:
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import (TracerProvider, Tracer, Span)
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.context import get_current
except ImportError:
    raise ImportError(
        "To use the opentelemetry-api, ...sdk and exporter-otlp callback manager you need to have the "
        "`opentelemetry` python package installed. Please install it with"
        " `pip install opentelemetry-api opentelemetry-sdk opentelemetry-exporter-otlp`"
    )

def _flatten_dict(
    nested_dict: Dict[str, Any], parent_key: str = "", sep: str = "_"
) -> Iterable[Tuple[str, Any]]:
    for key, value in nested_dict.items():
        new_key = parent_key + sep + key if parent_key else key
        if isinstance(value, dict):
            yield from _flatten_dict(value, new_key, sep)
        else:
            yield new_key, value

def flatten_dict(
    nested_dict: Dict[str, Any], parent_key: str = "", sep: str = "_"
) -> Dict[str, Any]:
    flat_dict = {k: v for k, v in _flatten_dict(nested_dict, parent_key, sep)}
    # for key, value in nested_dict.items():
    #     if isinstance(value, dict):
    #         yield key, str(value)
    return flat_dict

def transformed_messages(messages: List[BaseMessage]):
    return [(d.dict()) for d in messages]

class HCXCallbackHandler(BaseCallbackHandler):
    """Callback Handler that tracks HCX info."""
    
    name: str = "Callback"
    tracer: Tracer = None
    context: Span = None
    step: int = 0 

    def __init__(
        self,
        name: str,
        resource: Dict[str, Any],
        endpoint: str
    ) -> None:
        super().__init__()
        
        _resource = Resource.create(resource or {"service.name": "langchain-hcx"})
        _trace_provider = TracerProvider(resource=_resource)
        trace.set_tracer_provider(_trace_provider)
        _span_exporter = OTLPSpanExporter(endpoint=(endpoint or "http://otel-collector.otel.svc:4318")+"/v1/traces")
        trace.get_tracer_provider().add_span_processor(BatchSpanProcessor(_span_exporter))

        self.name = name
        self.tracer = trace.get_tracer("HCXCallbackHandler")

    def add_event(self, name: str, resp: Dict[str, Any]):
        if name.endswith("_start"):
            if self.step == 0:
                self.context = self.tracer.start_span(name)
            self.step += 1

        self.context.add_event(name, resp)

        if name.endswith("_end"):
            self.step -= 1
            if self.step <= 0:
                self.context.end()
                self.step = 0

    @property
    def always_verbose(self) -> bool:
        """Whether to call verbose callbacks even if verbose is False."""
        return True

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when LLM starts running."""
        resp: Dict[str, Any] = flatten_dict(serialized)
        resp.update({"prompts": prompts})
        self.add_event("on_llm_start", resp)

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        """Run when a chat model starts running."""
        resp: Dict[str, Any] = flatten_dict(serialized)
        resp.update({"messages": str([transformed_messages(mlist) for mlist in messages])})
        self.add_event("on_chat_model_start", resp)

    def on_llm_new_token(
        self,
        token: str,
        *,
        chunk: Optional[Union[GenerationChunk, ChatGenerationChunk]] = None,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on new LLM token. Only available when streaming is enabled."""
        resp: Dict[str, Any] = {"token": token}
        resp.update({"chunk": chunk.dict()})
        self.add_event("on_llm_new_token", resp)

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when LLM ends running."""
        resp: Dict[str, Any] = flatten_dict(response.dict())
        resp['generations'] = str(resp['generations'])
        resp['run'] = str(resp['run'])
        self.add_event("on_llm_end", resp)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when LLM errors.
        Args:
            error (BaseException): The error that occurred.
            kwargs (Any): Additional keyword arguments.
                - response (LLMResult): The response which was generated before
                    the error occurred.
        """
        resp: Dict[str, Any] = {"error": error.args}
        self.add_event("on_llm_error", resp)

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when chain starts running."""
        resp: Dict[str, Any] = flatten_dict(serialized)
        resp.update({"inputs": str(flatten_dict(inputs))})
        self.add_event("on_chain_start", resp)

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when chain ends running."""
        resp: Dict[str, Any] = flatten_dict(outputs)
        self.add_event("on_chain_end", resp)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when chain errors."""
        resp: Dict[str, Any] = {"error": error.args}
        self.add_event("on_chain_error", resp)

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when tool starts running."""
        resp: Dict[str, Any] = flatten_dict(serialized)
        resp.update({"input_str": input_str})
        self.add_event("on_tool_start", resp)

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when tool ends running."""
        resp: Dict[str, Any] = {"output": output}
        self.add_event("on_tool_end", resp)

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run when tool errors."""
        resp: Dict[str, Any] = {"error": error.args}
        self.add_event("on_tool_error", resp)

    def on_text(
        self,
        text: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on arbitrary text."""
        resp: Dict[str, Any] = {"text": text}
        self.add_event("on_text", resp)

    def on_retry(
        self,
        retry_state: RetryCallState,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        """Run on a retry event."""
        resp: Dict[str, Any] = {}
        self.add_event("on_retry", resp)

    def on_agent_action(
        self,
        action: AgentAction,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on agent action."""
        resp: Dict[str, Any] = flatten_dict(action.dict())
        self.add_event("on_agent_action", resp)

    def on_agent_finish(
        self,
        finish: AgentFinish,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on agent end."""
        resp: Dict[str, Any] = flatten_dict(finish.dict())
        self.add_event("on_agent_finish", resp)

    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on retriever start."""
        resp: Dict[str, Any] = flatten_dict(serialized)
        resp.update({"query": query})
        self.add_event("on_retriever_start", resp)

    def on_retriever_end(
        self,
        documents: Sequence[Document],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on retriever end."""
        resp: Dict[str, Any] = {"documents": [transformed_messages(d) for d in documents]}
        self.add_event("on_retriever_end", resp)

    def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        """Run on retriever error."""
        resp: Dict[str, Any] = {"error": error.args}
        self.add_event("on_retriever_error", resp)

    def __del__(self):
        self.context.end()
        self.context = None

    def __copy__(self) -> "HCXCallbackHandler":
        """Return a copy of the callback handler."""
        return self

    def __deepcopy__(self, memo: Any) -> "HCXCallbackHandler":
        """Return a deep copy of the callback handler."""
        return self
