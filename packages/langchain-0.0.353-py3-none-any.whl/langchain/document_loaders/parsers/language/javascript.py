from langchain_community.document_loaders.parsers.language.javascript import (
    JavaScriptSegmenter,
)

__all__ = ["JavaScriptSegmenter"]
